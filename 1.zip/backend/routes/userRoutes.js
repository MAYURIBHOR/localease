const express = require("express");
const router = express.Router();
const db = require("../config/db");

/* ================= REGISTER ================= */
router.post("/register", (req, res) => {
  const { name, email, password, role } = req.body;

  // 1️⃣ Empty field validation
  if (!name || !email || !password || !role) {
    return res.status(400).json({ message: "All fields are required" });
  }

  // 2️⃣ Email format validation
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailRegex.test(email)) {
    return res.status(400).json({ message: "Invalid email format" });
  }

  // 3️⃣ Password length validation
  if (password.length < 6) {
    return res
      .status(400)
      .json({ message: "Password must be at least 6 characters" });
  }

  // 4️⃣ Role validation (DB ENUM)
  if (!["user", "provider", "admin"].includes(role)) {
    return res.status(400).json({ message: "Invalid role" });
  }

  // 5️⃣ Check if email already exists
  const checkEmail = "SELECT id FROM users WHERE email = ?";
  db.query(checkEmail, [email], (err, result) => {
    if (err) return res.status(500).json({ message: "Database error" });

    if (result.length > 0) {
      return res.status(409).json({ message: "Email already registered" });
    }

    // 6️⃣ Insert user
    const insertUser = `
      INSERT INTO users (name, email, password, role, status)
      VALUES (?, ?, ?, ?, 'active')
    `;

    db.query(insertUser, [name, email, password, role], (err) => {
      if (err) {
        console.error(err);
        return res.status(500).json({ message: "Registration failed" });
      }

      res.status(201).json({ message: "Registration successful" });
    });
  });
});

module.exports = router;