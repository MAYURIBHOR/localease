class Booking {
  constructor(id, userId, serviceId, bookingDate, status) {
    this.id = id;
    this.userId = userId;
    this.serviceId = serviceId;
    this.bookingDate = bookingDate;
    this.status = status;
  }
}