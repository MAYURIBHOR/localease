const express = require("express");
const dotenv = require("dotenv");
const cors = require("cors");

require("./config/db"); // ✅ JUST IMPORT (NO FUNCTION CALL)
const userRoutes = require("./routes/userRoutes");

dotenv.config();

const app = express();

/* ========= MIDDLEWARE ========= */
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

/* ========= ROUTES ========= */
app.use("/users", userRoutes);

/* ========= TEST ========= */
app.get("/", (req, res) => {
  res.send("LocalEase API is running 🚀");
});

/* ========= SERVER ========= */
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`✅ Server running on http://localhost:${PORT}`);
});